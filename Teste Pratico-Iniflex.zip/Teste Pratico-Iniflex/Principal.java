import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;



public class Principal {
    
    public static void main(String[] args) {
        List<Pessoa> todosFuncionarios = inserirFuncionarios(); //Inserir todos os funcionários
        todosFuncionarios = removerFuncionario(todosFuncionarios, "João"); //Deletar funcionário com nome joão
        
        /* Imprimir todos os funcionários com todas suas informações, sendo que:
            •    informação de data deve ser exibido no formato dd/mm/aaaa;
            • informação de valor numérico deve ser exibida no formatado com separador de milhar como ponto e decimal como vírgula  */
        System.out.println("Todos funcionários:\n "+todosFuncionarios.toString()); 
        
        /*Os funcionários receberam 10% de aumento de salário, atualizar a lista de funcionários com novo valor.  */ 
        todosFuncionarios = aumentarSalariosFuncionarios(todosFuncionarios, 1.10); 
        System.out.println("Com aumento de salario:"+todosFuncionarios.toString());

        /*Agrupar os funcionários por função em um MAP, sendo a chave a “função” e o valor a “lista de funcionários”. */
         HashMap<String, List<Pessoa>> funcionariosAgrupados = agruparFuncionarios(todosFuncionarios);
         
         /* Imprimir os funcionários, agrupados por função. */
         for(String key : funcionariosAgrupados.keySet()){
             System.out.println("Função:"+key + "\n Funcionários:\n " + funcionariosAgrupados.get(key));
           }

            /*Imprimir os funcionários que fazem aniversário no mês 10 e 12 */
           mostrarFuncionarioAniversario(funcionariosAgrupados, 10, 12);

            /*Imprimir o funcionário com a maior idade, exibir os atributos: nome e idade. */
           mostrarFuncionarioComMaiorIdade(funcionariosAgrupados);

            /*Imprimir a lista de funcionários por ordem alfabética */
           mostrarPorOrdemAlfabetica(todosFuncionarios);
            /*Imprimir o total dos salários dos funcionários */
            mostrarSomaDosSalarios(funcionariosAgrupados);

            /*Imprimir quantos salários mínimos ganha cada funcionário, considerando que o salário mínimo é R$1212.00 */
            qntSalarioMinimosPorFuncionario(funcionariosAgrupados);
    }
    
       //Inserir todos os funcionários, na mesma ordem e informações da tabela acima.
    public static List<Pessoa> inserirFuncionarios(){
        List<Pessoa> pessoas = new ArrayList<>();
        String nome="", funcao="";
        LocalDate data=null;
        BigDecimal salario;

        nome= "Maria"; data=LocalDate.of(2000,10,18); salario= BigDecimal.valueOf(2009.44); funcao="Operador"; 
        Funcionario f1 = new Funcionario(nome, data , salario, funcao);
        pessoas.add(f1);

        nome= "João"; data= LocalDate.of(1990,5,12); salario= BigDecimal.valueOf(2284.38); funcao="Operador";
        Funcionario f2 = new Funcionario(nome, data , salario, funcao);
        pessoas.add(f2);

        nome= "Caio"; data= LocalDate.of(1961,5,2); salario= BigDecimal.valueOf(9836.14); funcao="Coordenador";
        Funcionario f3 = new Funcionario(nome, data , salario, funcao);
        pessoas.add(f3);

        nome= "Miguel"; data= LocalDate.of(1988,10,14); salario= BigDecimal.valueOf(19119.88); funcao="Diretor";
        Funcionario f4 = new Funcionario(nome, data , salario, funcao);
        pessoas.add(f4);

        nome= "Alice"; data= LocalDate.of(1995,1,5); salario= BigDecimal.valueOf(2234.68); funcao="Recepcionista";
        Funcionario f5 = new Funcionario(nome, data , salario, funcao);
        pessoas.add(f5);

        nome= "Heitor"; data= LocalDate.of(1999,11,19); salario= BigDecimal.valueOf(1582.72); funcao="Operador";
        Funcionario f6 = new Funcionario(nome, data , salario, funcao);
        pessoas.add(f6);

        nome= "Arthur"; data= LocalDate.of(1993,3,31); salario= BigDecimal.valueOf(4071.84); funcao="Contador";
        Funcionario f7 = new Funcionario(nome, data , salario, funcao);
        pessoas.add(f7);
        
        nome= "Laura"; data= LocalDate.of(1994,7,8); salario= BigDecimal.valueOf(3017.45); funcao="Gerente";
        Funcionario f8 = new Funcionario(nome, data , salario, funcao);
        pessoas.add(f8);

        nome= "Heloísa"; data= LocalDate.of(2003,5,24); salario= BigDecimal.valueOf(1606.85); funcao="Eletricista";
        Funcionario f9 = new Funcionario(nome, data , salario, funcao);
        pessoas.add(f9);

        nome= "Helena"; data= LocalDate.of(1996,9,2); salario= BigDecimal.valueOf(2799.93); funcao="Gerente";
        Funcionario f10 = new Funcionario(nome, data , salario, funcao);
        pessoas.add(f10);
        
        return pessoas;
    }
    

    //Remover o funcionário “João” da lista.
    public static List<Pessoa>  removerFuncionario(List<Pessoa> funcionarios, String nome){
        Pessoa joao = new Pessoa();
        for (Pessoa p : funcionarios) {
           if(p.getNome().equals(nome)){ joao = p; }
        }
        funcionarios.remove(joao);
        return funcionarios;
    }
    
    public static List<Pessoa> aumentarSalariosFuncionarios(List<Pessoa> funcionarios, double n){
        for (Pessoa pessoa : funcionarios) {
            pessoa.setSalario(pessoa.getSalario().multiply(new BigDecimal(n)));
        }
        return funcionarios;
    }

    public static HashMap<String, List<Pessoa>> agruparFuncionarios(List<Pessoa> funcionarios){
        HashMap<String, List<Pessoa>> porFuncao = new HashMap<>();
        List<Pessoa> funcionarioss = funcionarios;
        for (Pessoa pessoa : funcionarioss) {
            String funcao= pessoa.getFuncao();
            if(porFuncao.containsKey(funcao)){
                List<Pessoa> funcs = porFuncao.get(funcao);
                funcs.add(pessoa);
            }else{
                List<Pessoa> p = new ArrayList<>();
                p.add(pessoa);
                porFuncao.put(funcao, p);
            }
        }
        return porFuncao;
    }
    public static void mostrarFuncionarioAniversario(HashMap<String, List<Pessoa>> funcionariosAgrupados, int mes1, int mes2){
        for(String key : funcionariosAgrupados.keySet()){
                for (Pessoa pessoa : funcionariosAgrupados.get(key)) {
                    if(pessoa.getDataNascimento().getMonthValue() == 10 || pessoa.getDataNascimento().getMonthValue() == 12){
                        System.out.println("Funcionário(a) "+pessoa.getNome() + " faz aniversario no mes:"+pessoa.getDataNascimento().getMonthValue());
                    }
                }
        }
    }

    public static void mostrarFuncionarioComMaiorIdade(HashMap<String, List<Pessoa>> funcionariosAgrupados){
        Pessoa p = new Pessoa();
        int idade=0, maxIdade=0;
        for(String key : funcionariosAgrupados.keySet()){
                for (Pessoa pessoa : funcionariosAgrupados.get(key)) {
                    idade = 2023 - pessoa.getDataNascimento().getYear();
                    if(idade> maxIdade){
                        maxIdade=idade;
                        p = pessoa;
                    }
                }
        }
             System.out.println("Funcionário(a) que tem a maior idade: "+p.getNome() + " com "+ idade + " anos de idade.");
    }
    public static void mostrarPorOrdemAlfabetica(List<Pessoa> funcionarios){
        System.out.println("\n Lista original:\n"+funcionarios.toString());
        funcionarios.sort(null);
        System.out.println("\n Lista Ordenada:\n"+ funcionarios.toString());  
    }
    public static void mostrarSomaDosSalarios(HashMap<String, List<Pessoa>> funcionariosAgrupados){
        BigDecimal SomaSalario = new BigDecimal(0); 
        DecimalFormat formatSalario = new DecimalFormat("#,###.00");
        for(String key : funcionariosAgrupados.keySet()){
                for (Pessoa pessoa : funcionariosAgrupados.get(key)) {
                    SomaSalario = pessoa.getSalario().add(SomaSalario);
                }
        }   
        System.out.println("\n A soma do salário dos funcionários: "+ String.valueOf(formatSalario.format(SomaSalario)).replace('.', 'd').replace(',', '.').replace('d', ','));
    }
    public static void qntSalarioMinimosPorFuncionario(HashMap<String, List<Pessoa>> funcionariosAgrupados){
        String mostrar= "";
        BigDecimal qntSalario= new BigDecimal(0) ;
        for(String key : funcionariosAgrupados.keySet()){
                for (Pessoa pessoa : funcionariosAgrupados.get(key)) {
                    qntSalario = pessoa.getSalario().divideToIntegralValue(new BigDecimal(1212)).setScale(0, RoundingMode.DOWN);
                    mostrar = mostrar + pessoa.getNome() + " ganha " + qntSalario + " salario(s) minimo(s)\n";
                }
        } 
        System.out.println("\n "+mostrar);
    }
    
    

    




}

